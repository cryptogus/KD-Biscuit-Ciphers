#include "tests/xvddraes_test/key_expansion.hpp"
#include "tests/xvddraes_test/xts_aes_256_tv_wrap.hpp"
#include "tests/xvparams.hpp"
#include "tests/xvtest.hpp"

class XvDdrAesTest : public TestFixture
{
public:
    void setUp()
    {
    }
    void tearDown()
    {
    }
};

TEST_F(XvDdrAesTest, XtsAes256Encrypt)
{
    for (size_t i = 0; i < ENCRYPT_TEST_COUNT; ++i)
    {
        uint8_t roundKey[15][16];
        AesKeyExpansion::expansionKeyAES256(aesXtsTvEnc[i].key, roundKey);

        // Here you would typically call the encryption function with the roundKey
    }
}

TEST_F(XvDdrAesTest, XtsAes256Decrypt)
{
    for (size_t i = 0; i < DECRYPT_TEST_COUNT; ++i)
    {
        uint8_t roundKey[15][16];
        AesKeyExpansion::expansionKeyAES256(aesXtsTvDec[i].key, roundKey);

        // Here you would typically call the decryption function with the roundKey
    }
}